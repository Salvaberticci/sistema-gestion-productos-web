<?php
require_once __DIR__ . '/includes/auth.php';
$db = getDB();

$res = $db->query("SELECT COUNT(*) as total_p, SUM(exisact) as total_s FROM productos")->fetch();

echo "DEBUG STATS:\n";
echo "Total Products: " . $res['total_p'] . "\n";
echo "Total Stock: " . $res['total_s'] . "\n";

$res2 = $db->query("SELECT REFERENCE, exisact FROM productos ORDER BY exisact DESC LIMIT 1")->fetch();
echo "Highest Stock: " . ($res2['REFERENCE'] ?? 'N/A') . " (" . ($res2['exisact'] ?? '0') . ")\n";
